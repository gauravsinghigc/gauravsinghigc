	<section class="container">
		<div class="row p-1">
			<div class="col-md-1">
				<img src='img/user_pic/rsg_icon.png' class="logo_width" alt="RSG Store" title="RSG Store">
			</div>
			<div class="col-md-5">
				<h2>
					<em><b>Welcome :</b></em>
				<code><?php admin_name(); ?></code>
			</h2>
			</div>
			<div class="col-md-6 mt-2">
				<a href='logout.php' class="float-right m-1">
					<button class="btn btn-sm btn-danger">
						Logout
					</button>
				</a>
				<a href='account.php' class="float-right m-1">
					<button class="btn btn-sm btn-info">
						Account Settings
					</button>
				</a>
			</div>
		</div>
	</section>

	<section class="container">
		<div class="row p-1">
			<div class="col-md-5">
				<form action="results.php" method="POST">
					<TABLE align="center" class="logo_width">
						<tr>
							<td>
								<input type="text" name="search_query" placeholder="Search" class="form-control">
							</td>
							<td>
								<button class="btn btn-md btn-success" type="submit" name="submit">Search</button>
							</td>
						</tr>
					</TABLE>
				</form>
			</div>
			<div class="col-md-7 mt-1">
				<ul class="info_ul_li float-left logo_width">
					<li>
						<a href="rsg_admin.php">
							<button class="btn btn-sm btn-outline-info">Home Page</button>
						</a>
					</li>
					<li>
						<a href="add_user.php">
							<button class="btn btn-sm btn-outline-info">Add User <b> + </b></button>
						</a>
					</li>
					<li>
						<a href="upload.php">
							<button class="btn btn-sm btn-outline-danger">Upload Data <b> + </b></button>
						</a>
					</li>
				</ul>
			</div>
		</div><hr>
	</section>

	<section class="container">
	<div class="row">
		<div class="col-md-12">
			<ul class="info_ul_li float-left">
				<?php items_types(); cat_types() ?>
			</ul>
		</div>
	</div><hr>
</section>