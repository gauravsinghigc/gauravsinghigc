<?php
session_start();

if (isset($_POST['submit_form'])) {
	
	if ($_POST['submit_form'] == "submit_session_msg") {
		
		$username = $_POST['Username'];
		$password = $_POST['password'];

		if ($username == "gauravsinghigc" and $password == "9810895713") {
			
			header("location: admin.php");

			$_SESSION['name'] = "Gaurav Singh";
			$_SESSION['msg']  = "SuccessFully Login!";
		} else {

			header("location: error.php");

			$_SESSION['err_msg'] = "Please Enter Valid Information";

		}
	}
}
?>