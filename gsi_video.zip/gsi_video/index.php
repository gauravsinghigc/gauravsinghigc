<!DOCTYPE html>
<html>
<head>
	<?php require 'files.php';
	session_start();?>
	<title>Login : Gauravsinghigc</title>
</head>
<body>
	<section class="container">
		<div class="row align-center pt-5">
			<div class="col-md-6 offset-md-3 mt-5 table-bordered p-5">
				<h1 class="text-center"><em>Login! : RSG Store</em></h1><hr><br>
					<?php if (empty($_SESSION['msg'])) {
						 echo "";
					} elseif(isset($_SESSION['msg'])) {
						echo "<label class='col-md-12'><code class='float-left'>Aaey Bhangii, Sahi Password daal. </code>
						      <code class='float-right'>
						      <form action='remove.php' method='post'>
						      <input type='text' name='remove_msg' value='remove_msg' hidden>
						      <button class='btn btn-sm btn-outline-danger' type='submit' name='submit' value='submit' ><b>X</b></button>
						      </form>
						      </code>
						      </label>";
					} ?>
				<form class="mt-5" method="post" action="rsg_login.php">
					<label>Username<code>*</code> :</label>
					<input type="text" name="ip_address" value="<?php echo ip(); ?>" hidden="">
					<input type="text" name="username" class="form-control" placeholder="username" required=""><br><br>
						<label>Password<code>*</code> :</label>
					<input type="password" name="password" class="form-control" placeholder="*********" required=""><br><br>
					<button class="btn btn-lg btn-success" type="submit" name="submit">Login</button>
					
				</form>
			</div>
		</div>
	</section>

</body>
</html>