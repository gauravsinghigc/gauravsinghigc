<?php

require 'config.php';

function ip()
{
	ini_set("display_errors", 0);
	global $con;
	$ipaddress = '';
	if ($_SERVER['HTTP_CLIENT_IP'])
		$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
	else if ($_SERVER['HTTP_X_FORWARDED_FOR'])
		$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
	else if ($_SERVER['HTTP_X_FORWARDED'])
		$ipaddress = $_SERVER['HTTP_X_FORWARDED'];
	else if ($_SERVER['HTTP_FORWARDED_FOR'])
		$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
	else if ($_SERVER['HTTP_FORWARDED'])
		$ipaddress = $_SERVER['HTTP_FORWARDED'];
	else if ($_SERVER['REMOTE_ADDR'])
		$ipaddress = $_SERVER['REMOTE_ADDR'];
	else
		$ipaddress = 'UNKNOWN';
	return $ipaddress;
}


function profile_img(){
	global $con;
	$user_id = $_SESSION['id'];
	$sql = "SELECT * FROM user where user_id='$user_id'";
	$query = mysqli_query($con, $sql);
	$row = mysqli_fetch_assoc($query);
  if (empty($_row['image'])) {
  	echo "<img src='img/user_pic/no_pic.png' style='width:100%;' class='img-thumbnail'>";
  } elseif(!empty($_row['image'])){
  	$sql = "SELECT * FROM user where user_id='$user_id'";
  	$query = mysqli_query($con, $sql);
  	$row = mysqli_fetch_assoc($query);
  	$image = $row['image'];
  	echo "<img src='img/user_pic/$image' style='width:100%;' class='img-thumbnail'>";

  }
}

function admin_name(){
	global $con;
	$user_id = $_SESSION['id'];
	$sql = "SELECT * FROM user where user_id='$user_id'";
	$query = mysqli_query($con, $sql);
	$row = mysqli_fetch_assoc($query);
	$name = $row['full_name'];
	echo "$name";
}

function account(){
	global $con;
	$user_id = $_SESSION['id'];
	$sql = "SELECT * FROM user where user_id='$user_id'";
	$query = mysqli_query($con, $sql);
	$row = mysqli_fetch_assoc($query);
 $username = $row['username'];
 $password = $row['password'];
 $full_name = $row['full_name'];

 echo "
    <tr>
						<td><label>Full Name :</label></td>
						<td><input class='form-control' type='text' name='full_name' value='$full_name' placeholder='$full_name' required> </td>
					</tr>
					<tr>
						<td><label>Username :</label></td>
						<td><input class='form-control' type='text' name='username' value='$username' placeholder='username' required> </td>
					</tr>
					<tr>
						<td><label>Password :</label></td>
						<td><input class='form-control' type='text' name='password' value='$password' placeholder='password' required> </td>
					</tr>";
}

function select_item_type(){
	global $con;
	$sql = "SELECT * FROM items";
	$query = mysqli_query($con, $sql);
	while ($row = mysqli_fetch_array($query)) {
		$item_id = $row['item_id'];
		$item_title = $row['item_title'];

		echo "	<option name='item_type' value='$item_id' class='form-control'>$item_title</option>";
	}
}

function select_cat_type(){
	global $con;
	$sql = "SELECT * FROM categories";
	$query = mysqli_query($con, $sql);
	while ($row = mysqli_fetch_array($query)) {
		$cat_id = $row['cat_id'];
		$cat_title = $row['cat_title'];

		echo "	<option name='cat_type' value='$cat_id' class='form-control'>$cat_title</option>";
	}
}

function items_types(){
	global $con;
	$sql = "SELECT * FROM items";
	$query = mysqli_query($con, $sql);
	while ($row = mysqli_fetch_assoc($query)) {
		$item_id = $row['item_id'];
		$item_title = $row['item_title'];

		echo "<form action='results.php' method='post' class='float-left m-1'>
		<input type='text' name='item_type' value='$item_id' hidden>
		<button class='btn btn-sm btn-outline-info' type='submit' name='submit'>$item_title</button>
		</form>";
	}
}

function cat_types(){
	global $con;
	$sql = "SELECT * FROM categories";
	$query = mysqli_query($con, $sql);
	while ($row = mysqli_fetch_assoc($query)) {
		$item_id = $row['cat_id'];
		$item_title = $row['cat_title'];

		echo "<form action='results.php' method='post' class='float-left m-1'>
		<input type='text' name='cat_type' value='$item_id' hidden>
		<button class='btn btn-sm btn-outline-success' type='submit' name='submit'>$item_title</button>
		</form>";
	}
}

function cat_type_search(){
	global $con;
	if (isset($_POST['item_type'])) {
		$item_id = $_POST['item_type'];
		$sql = "SELECT * FROM files, categories, items where files.item_id='$item_id' and files.cat_id=categories.cat_id and items.item_id=files.item_id";
		$query = mysqli_query($con, $sql);

		while ($row = mysqli_fetch_array($query)) {
			$cat_title = $row['cat_title'];
			$item_title = $row['item_title'];
			$file_name = $row['file_name'];
			$description = $row['description'];
			$file = $row['file'];

			echo "
			<div class='col-md-3 box-shadow p-2'>
    <div class='row'>
      <div class='col-md-3'>
       <img src='img/user_pic/rsg_icon.png' class='logo_width' alt='$file_name' title='$file_name'>
      </div>
      <div class='col-md-9'>
      <h6><em>$file_name</em></h6><hr class='mt-0 mb-0'>
      <p class='mt-0 float-left'><em class='small'><b>Category:</b> </em>$cat_title</p>
      <p class='mt-0 float-right'><em class='small'><b>Type:</b> </em>$item_title</p>
      <p class='mt-0'>
     <a href='download.php?download=$file' target='_blank'>
      <button class='btn btn-sm btn-danger small'>
      Download
      </button></a>

      <a href='files/$file' downlaod='$file' target='_blank'>
      <button class='btn btn-sm btn-info small'>
      Play Now
      </button></a>
      </div>
    </div>
			</div>
	";
			
		}
	} elseif (isset($_POST['cat_type'])) {
		$cat_id = $_POST['cat_type'];
		$sql = "SELECT * FROM files, categories, items where files.cat_id='$cat_id' and files.cat_id=categories.cat_id and items.item_id=files.item_id";
		$query = mysqli_query($con, $sql);

		while ($row = mysqli_fetch_array($query)) {
			$cat_title = $row['cat_title'];
			$item_title = $row['item_title'];
			$file_name = $row['file_name'];
			$description = $row['description'];
			$file = $row['file'];
			$file_id = $row['file_id'];

			echo "
			<div class='col-md-3 box-shadow p-2'>
    <div class='row'>
      <div class='col-md-3'>
       <img src='img/user_pic/rsg_icon.png' class='logo_width' alt='$file_name' title='$file_name'>
      </div>
      <div class='col-md-9'>
      <h6><em>$file_name</em></h6><hr class='mt-0 mb-0'>
      <p class='mt-0 float-left'><em class='small'><b>Category:</b> </em>$cat_title</p>
      <p class='mt-0 float-right'><em class='small'><b>Type:</b> </em>$item_title</p>
      <p class='mt-0'>
      <a href='download.php?download=$file' target='_blank'>
      <button class='btn btn-sm btn-danger small'>
      Download
      </button></a>

      <a href='files/$file' target='_blank'>
      <button class='btn btn-sm btn-info small'>
      Play Now
      </button></a>
      </div>
    </div>
			</div>
	";
			}
		} elseif (isset($_POST['search_query'])) {
		echo "
        <center>
        <h1> Abey Intzaar Karrr thoda, avi Ban rhi h..., sav kuch aaj hi de du krke.</h1>
        </center>
        ";
	}
}