<section class="container"><hr>
	<div class="row">
		<div class="col-md-12">
			<center>
				<p>
					This Website is Property of <b>RSG Member</b>, which means this website have access for aunthorised persons only means any un-authorised person is blocked by RSG Group. <br>
					&copy; Copyrighted - All Right Reserved by <b>Gaurav Singh</b>, <b>Rahul G Shady</b>, and <b>Sameer Khan</b>.
				</p>
			</center>
		</div>
	</div>
</section>