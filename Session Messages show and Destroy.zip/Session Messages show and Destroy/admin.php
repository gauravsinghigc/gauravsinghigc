<?php session_start();
 if(empty($_SESSION['name'])){ header("location: index.php");}
 require 'fun.php'; ini_set("display_errors", 0); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
</head>
<body>
	<h2>Dear, <?php echo $_SESSION['name']; ?></h2>
	<p> Your are Successfully Login!</p>
     <?php success_msg(); ?>
</body>
</html>