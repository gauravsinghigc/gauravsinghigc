<?php
require 'files.php';
session_start();
if (isset($_POST['add_user'])) {
	$full_name = $_POST['full_name'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$password_2 = $_POST['password_2'];

	if ($password == $password_2) {
		 
		 $sql = "INSERT into user (username, password, full_name) VALUES ('$username', '$password', '$full_name')";
		 $query = mysqli_query($con, $sql);
		 if ($query == true) {
		 	header("location: add_user.php");
		 	$_SESSION['add_user'] = "User SuccessFully Added!";
		 } else {
		 		header("location: add_user.php");
		 }
	}
} elseif (isset($_POST['add_items'])) {
	$item_name = $_POST['item_name'];
	$sql = "INSERT INTO items (item_title) VALUES ('$item_name')";
	$query = mysqli_query($con, $sql);

		if ($query == true) {
		 	header("location: add_items.php");
		 	$_SESSION['inserted'] = "SuccessFully Added!";
		 } else {
		 		header("location: add_items.php");
		 }
} elseif (isset($_POST['add_categories'])) {
	$item_name = $_POST['cat_name'];
	$sql = "INSERT INTO categories (cat_title) VALUES ('$item_name')";
	$query = mysqli_query($con, $sql);

		if ($query == true) {
		 	header("location: add_cat.php");
		 	$_SESSION['inserted'] = "SuccessFully Added!";
		 } else {
		 		header("location: add_cat.php");
		 }
} elseif (isset($_POST['Upload_data'])) {
	$item_id = $_POST['item_type'];
	$cat_id  = $_POST['cat_type'];
	$file_name = $_POST['file_name'];
	$description = $_POST['description'];

	$file_data = $_FILES['file_data']['name'];
	$tmp_name = $_FILES['file_data']['tmp_name'];
	$dir      = "files/";
	move_uploaded_file($_FILES['file_data']['tmp_name'], $dir.$file_data);

		$sql = "INSERT into files (item_id, cat_id, file_name, description, file) VALUES ('$item_id', '$cat_id', '$file_name', '$description', '$file_data')";
		$query = mysqli_query($con, $sql);
	if ($query == true) {
		header("location: upload.php");
		$_SESSION['uploaded'] = "Successfully! uploaded";
	}
}