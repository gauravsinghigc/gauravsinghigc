<?php
function success_msg(){
	if (isset($_SESSION['msg'])) {
		$success_msg = $_SESSION['msg'];
	echo  "<p><b>Message:</b>  <em>$success_msg</em> <a href='remove_msg.php'>Remove Message</a><p>";
	} else {
		echo "";
	}
	
}

function err_msg (){
	if (isset($_SESSION['err_msg'])) {
		$err_msg = $_SESSION['err_msg'];
		echo "<p><b>Message:</b>  <em>$err_msg</em> <a href='remove_msg.php'>Login Again!</a><p>";
	}
}

?>