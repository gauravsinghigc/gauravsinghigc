<!DOCTYPE html>
<html>
<head>
    <title>Session Messages</title>
</head>
<body>
    <h3>Fill the required Data</h3>
    <form action="login.php" method="post">
        <label>Enter The Username:</label>
        <input type="text" name="Username" placeholder="Enter the Username"><br><br>

        <label>Enter The Password</label>
        <input type="password" name="password" placeholder="enter the password"><br><br>

        <button type="submit" name="submit_form" value="submit_session_msg">Submit</button>
    </form>

</body>
</html>