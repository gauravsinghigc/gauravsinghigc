<!DOCTYPE html>
<html>
<head>
<?php 
require 'files.php'; 
session_start();
if (empty($_SESSION['id'])) {
	 	header("location: index.php");
	} ?>
	<title> Account Page : RSG Store</title>
</head>
<body>
	<?php require 'header_bar.php'; ?>
	<section class="container">
		<div class="row">
			<div class="col-md-12">
			<center class="text-center">
				<p>
				Dear,	<?php admin_name();?> This is your account Page. Change, update your account information from here.
				</p>
			</center><hr>
		</div>
		<div class="col-md-6 offset-md-3">
			<h6 class="red_under">Change your Details:</h6>
			<form action='update.php' method="POST" class="p-3">
				<table align="center" class="logo_width">
	    <?php account(); ?>
				</table><hr>
				<center>
				 <button class="btn btn-lg btn-success" type="submit" name="submit"> Update </button>
				</center>
			</form>
		</div>
	</section>

	<?php require 'footer.php'; ?>

</body>
</html>