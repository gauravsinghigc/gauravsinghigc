<!DOCTYPE html>
<html>
<head>
<?php 
require 'files.php'; 
session_start();
if (empty($_SESSION['id'])) {
	 	header("location: index.php");
	} ?>
	<title> Add User : RSG Store</title>
</head>
<body>
	<?php require 'header_bar.php'; ?>
	<section class="container">
		<div class="row">
			<div class="col-md-12">
			<center class="text-center">
				<?php 
				if (empty($_SESSION['add_user'])) {
					echo "";
				} elseif (!empty($_SESSION['add_user'])) {
					echo "<code>".$_SESSION['add_user']."</code>";
					echo " <a href='remove.php'>
					<button class='btn btn-sm btn-outline-danger'><b>x</b></button></a>";
				}
				?>
			</center><hr>
		</div>
		<div class="col-md-6 offset-md-3">
			<h6 class="red_under">ADD New User:</h6>
			<form action='insert.php' method="POST" class="p-3">
				<input type="text" name="add_user" value="add_user" hidden="">
				<table align="center" class="logo_width">
	    <tr>
						<td><label>Full Name :</label></td>
						<td><input class='form-control' type='text' name='full_name' value='' placeholder='Full Name' required> </td>
					</tr>
					<tr>
						<td><label>Username :</label></td>
						<td><input class='form-control' type='text' name='username' value='' placeholder='username' required> </td>
					</tr>
					<tr>
						<td><label>Password :</label></td>
						<td><input class='form-control' type='password' name='password' value='' placeholder='********' required> </td>
					</tr>
					<tr>
						<td><label>Re-Password :</label></td>
						<td><input class='form-control' type='password' name='password_2' value='' placeholder='*********' required> </td>
					</tr>
				</table><hr>
				<center>
				 <button class="btn btn-lg btn-success" type="submit" name="submit"> Update </button>
				</center>
			</form>
		</div>
	</section>

	<?php require 'footer.php'; ?>

</body>
</html>