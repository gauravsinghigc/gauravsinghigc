<?php
session_start();
require 'files.php';

if (isset($_POST['submit'])) {

	$username = $_POST['username'];
	$password = $_POST['password'];
	$ip_address = $_POST['ip_address'];

	 $sql = "SELECT * FROM user where username='$username' and password='$password'";
	 $query = mysqli_query($con, $sql);
	 $row = mysqli_fetch_assoc($query);

	 if ($row == true) {
   $user_id = $row['user_id'];
	 	$time_date = date('Y-m-d H:i a');
	 	$sql = "INSERT into logins (user_id, ip_address, at_date_time) VALUE ('$user_id', '$ip_address', '$time_date')";
	 	$query = mysqli_query($con, $sql);

	 	if ($query == true ){
	 	header("location: rsg_admin.php");
	 	$_SESSION['id'] = $row['user_id'];
	 } else {
	 	header("location: index.php");
	 	$_SESSION['msg'] = "9810";
	  } 
	 } else {
	 	header("location: index.php");
	 	$_SESSION['msg'] = "9810";
	 }
}

?>