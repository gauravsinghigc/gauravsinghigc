<!DOCTYPE html>
<html>
<head>
	<?php 
session_start();
	require 'files.php';
	if (empty($_SESSION['id'])) {
	 	header("location: index.php");
	}
 ?>
	<title>Home Page : RSG</title>
</head>
<body>
<?php require 'header_bar.php'; ?>

<section class="container">
	<div class="row">
		<div class="col-md-12">
			<center>
				<h1>Welcome! Choose your items and enjoy it according to you with out any advertisement and any type disturbing.</h1>
				<h2>Happy Net Surfing.</h2>
				<h1><code>RSG Bijjar World</code></h1>
			</center>
		</div>
	</div>
</section>

<?php require 'footer.php'; ?>
</body>
</html>
