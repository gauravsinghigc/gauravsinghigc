<?php session_start(); require 'fun.php'; ini_set("display_errors", 0);  ?>
<!DOCTYPE html>
<html>
<head>
	<title>Error</title>
</head>
<body>
<h2>Something Went Wrong!</h2>
<p><?php err_msg(); ?></p>
</body>
</html>