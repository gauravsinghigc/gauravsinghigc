<?php

$host = "localhost";
$user = "root";
$pass = "";
$db   = "rsg_store";

$con = new mysqli($host, $user, $pass, $db);

if ($con == true){
	echo "";
} else {
	echo "<b>Connection Failed :</b> ".mysqli_error($con);
}

?>