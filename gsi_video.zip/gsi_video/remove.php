<?php
session_start();

if (isset($_POST['remove_msg'])) {
	unset($_SESSION['msg']);
	header("location: index.php");
} elseif (isset($_SESSION['add_user'])) {
	unset($_SESSION['add_user']);
	header("location: add_user.php");
} elseif (isset($_SESSION['err'])) {
	unset($_SESSION['err']);
	header("location: upload.php");
} elseif (isset($_SESSION['inserted'])) {
	unset($_SESSION['inserted']);
	header("location: add_items.php");
}  elseif (isset($_SESSION['uploaded'])) {
	unset($_SESSION['uploaded']);
	header("location: upload.php");
}