<!DOCTYPE html>
<html>
<head>
	<?php 
session_start();
	require 'files.php';
	if (empty($_SESSION['id'])) {
	 	header("location: index.php");
	}
 ?>
	<title>Home Page : RSG</title>
</head>
<body>
<?php require 'header_bar.php'; ?>

<section class="container">
	<div class="row">
	<?php cat_type_search(); ?>
</div>
</section>

<?php require 'footer.php'; ?>
</body>
</html>
