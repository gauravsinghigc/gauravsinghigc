<!DOCTYPE html>
<html>
<head>
<?php 
require 'files.php'; 
session_start();
if (empty($_SESSION['id'])) {
	 	header("location: index.php");
	} ?>
	<title> Upload Data : RSG Store</title>
</head>
<body>
	<?php require 'header_bar.php'; ?>
	<section class="container">
		<div class="row">
			<div class="col-md-12">
			<center class="text-center">
				<?php 
				if (empty($_SESSION['uploaded'])) {
					echo "";
				} elseif (!empty($_SESSION['uploaded'])) {
					echo "<code>".$_SESSION['uploaded']."</code>";
					echo " <a href='remove.php'>
					<button class='btn btn-sm btn-outline-danger'><b>x</b></button></a>";
				} elseif (!empty($_SESSION['err'])) {
					echo "<code>".$_SESSION['err']."</code>";
					echo " <a href='remove.php'>
					<button class='btn btn-sm btn-outline-danger'><b>x</b></button></a>";
				} elseif (empty($_SESSION['err'])) {
      echo "";
     }
				?>
			</center><hr>
		</div>
		<div class="col-md-6 offset-md-3">
			<a href="add_cat.php">
				<button class="btn btn-sm btn-info">Add Categories <b>+</b></button>
			</a>
				<a href="add_items.php">
				<button class="btn btn-sm btn-danger">Add Items <b>+</b></button>
			</a>
			<form action='insert.php' method="POST" class="p-3" enctype="multipart/form-data">
				<input type="text" name="Upload_data" value="Upload_data" hidden="">
				<table align="center" class="logo_width">
	    <tr>
						<td><label>Select Item Type :</label></td>
						<td>
							<select class="form-control" name="item_type" required="">
								<option name="item_type" value="0" class="form-control">---Select Item Type:-------</option>
								<?php select_item_type(); ?>
							</select>
						</td>
					</tr>
					<tr>
						<td><label>Select Category :</label></td>
						<td>
							<select class="form-control" name="cat_type" required="">
								<option name="cat_type" value="0" class="form-control">---Select Categories:-------</option>
								<?php select_cat_type(); ?>
							</select>
						</td>
					</tr>
					<tr>
						<td><label>File Name :</label></td>
						<td><input class='form-control' type='text' name='file_name' value='' placeholder='file name' required> </td>
					</tr>
					<tr>
						<td><label>Description :</label></td>
						<td><input class='form-control' type='text' name='description' value='' placeholder='Description' required> </td>
					</tr>
						<tr>
						<td><label>Upload Files :</label></td>
						<td><input type='file' name='file_data' required=""> </td>
					</tr>
				</table><hr>
				<center>
				 <button class="btn btn-lg btn-success" type="submit" name="submit"> Upload </button>
				</center>
			</form>
		</div>
	</section>

	<?php require 'footer.php'; ?>

</body>
</html>