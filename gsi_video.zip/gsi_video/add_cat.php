<!DOCTYPE html>
<html>
<head>
<?php 
require 'files.php'; 
session_start();
if (empty($_SESSION['id'])) {
	 	header("location: index.php");
	} ?>
	<title> ADD Categories : RSG Store</title>
</head>
<body>
	<?php require 'header_bar.php'; ?>
	<section class="container">
		<div class="row">
			<div class="col-md-12">
			<center class="text-center">
				<?php 
				if (empty($_SESSION['inserted'])) {
					echo "";
				} elseif (!empty($_SESSION['inserted'])) {
					echo "<code>".$_SESSION['inserted']."</code>";
					echo " <a href='remove.php'>
					<button class='btn btn-sm btn-outline-danger'><b>x</b></button></a>";
				}
				?>
			</center><hr>
		</div>
		<div class="col-md-6 offset-md-3">
			<h4><b>ADD Categories:</b></h4>
			<form action='insert.php' method="POST" class="p-3">
				<input type="text" name="add_categories" value="add_categories" hidden="">
				<table align="center" class="logo_width">
	    <tr>
						<td><label>Category Name :</label></td>
						<td><input class='form-control' type='text' name='cat_name' value='' placeholder='Categories Name' required> </td>
					</tr>
				</table><hr>
				<center>
				 <button class="btn btn-lg btn-success" type="submit" name="submit"> Save </button>
				</center>
			</form>
		</div>
	</section>

	<?php require 'footer.php'; ?>

</body>
</html>