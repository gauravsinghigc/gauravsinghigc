<?php
session_start();

if (isset($_SESSION['msg'])) {
	unset($_SESSION['msg']);
header("location: admin.php");
} elseif ($_SESSION['err_msg']) {
	unset($_SESSION['err_msg']);
header("location: index.php");
}



?>